***** Important Notice *****


The following instructions describe the BIOS update process of the H12 projects 2.x Rome/Milan BIOS flash package.  
( Update BIOS from version 2.x to version 2.x )

Please follow the instructions carefully to prevent the need of any RMA repair or replacement.

The package includes:

- afuefi.smc (AFUEFI64 5.14.03.0039)

================================================
Standard BIOS Update Procedure under UEFI Shell
================================================

1. Save the BIOS update package to your computer.

2. Extract the files from the UEFI folder of the BIOS package to a USB stick. 
   (Note: The USB stick doesn't have to be bootable, but has to be formatted
   with the FAT/FAT32 file system.)

3. Plug the USB stick into a USB port, boot to the Build-In UEFI Shell, and
   type FLASH.nsh BIOSname#.### to start the BIOS update:

     Shell> fs0:
     fs0:\> cd UEFI
     fs0:\UEFI> flash.nsh H12SSW0.B11

4. Do not interrupt the process until the BIOS update is complete.

5. Perform an A/C power cycle after the message indicating the BIOS update
   has completed.

6. Go to the BIOS configuration, and restore the BIOS settings.



Notes:

* Supermicro no longer supports the BIOS update method in DOS.

* If the BIOS flash fails, you may contact our RMA Dept. to have the BIOS
  chip reprogrammed.  This will require shipping the board to our RMA Dept.
  for repair.  Please submit your RMA request at 
  http://www.supermicro.com/support/rma/.



********* BIOS Naming Convention **********

-(For BIOS 1.3 or earlier)-

BIOS name  : PPPPPSSY.MDD
PPPPP      : 5-Bytes for project name
SS         : 2-Bytes supplement for PPPPP (if applicable)
Y          : Year, 5 -> 2015, 6-> 2016, 7->2017
MDD        : Month + Date, for months, A -> Oct., B -> Nov., C -> Dec.

E.g., For BIOS with the build date, 11/11/2020:
        H12SSW-iN/NT -> H12SSW0.B11
        
-(For BIOS 2.0 or later)-

BIOS name  : BIOS_H12XXXXX-BBBB_YYYYMMDD_VVV_T.TTt_STDsp.bin

"BIOS"     : BIOS image identifier
H12XXXXX   : Project name
BBBB       : 4-digit project ID
YYYY       : Year of the build date
MM         : Month of the build date
DD         : Day of the build date
T.Tt       : BIOS revision number
"STD"      : Standard BIOS ("OEM" = Custom BIOS)
"sp"       : Production signed image (No "sp" means Unsigned.)

Examples:
           H12SSW-iN/NT -> BIOS_H12SSW-1B2B_20210222_2.0_STDsp.bin



---Last Update on: 06/24/2021---