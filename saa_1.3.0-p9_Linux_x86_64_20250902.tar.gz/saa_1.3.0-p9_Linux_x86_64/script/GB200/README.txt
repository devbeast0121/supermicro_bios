Please fill the remote BMC host IP/User Name/Password to enable RHI for the remote BMC host in "GB200_enable_RHI.sh".
