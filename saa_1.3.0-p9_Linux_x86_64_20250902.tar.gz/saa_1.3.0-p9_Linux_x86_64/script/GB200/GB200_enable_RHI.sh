#!/bin/bash
# Scipt to temporarily enable Redfish Host Interface on GB200 system.
# Please fill in below variables
BMC=
USERNAME=""
PASSWORD=""
URL="https://$BMC/redfish/v1/Managers/BMC_0/EthernetInterfaces/hostusb0"

# Ensure required environment variables are set
if [[ -z "$USERNAME" || -z "$PASSWORD" || -z "$BMC" ]]; then
  echo "Error: Please set the environment variables USERNAME, PASSWORD, and BMC before running this script."
  echo "Usage: export USERNAME='your-username', PASSWORD='your-password', BMC='BMC-IP-or-hostname'"
  exit 1
fi

# Define the JSON payload
PAYLOAD='{
  "DHCPv4": {
    "DHCPEnabled": false
  },
  "IPv4StaticAddresses": [
    {
      "Address": "169.254.3.254",
      "SubnetMask": "255.255.0.0",
      "Gateway": "169.254.3.254"
    }
  ]
}'

# Print informational messages
echo "Target BMC: $BMC"
echo "Sending PATCH request to $URL..."

# Execute the curl command
curl -k -v -X PATCH \
  -H "Content-Type: application/json" \
  -u "$USERNAME:$PASSWORD" \
  -d "$PAYLOAD" \
  "$URL"

# Check the exit status of curl
if [[ $? -eq 0 ]]; then
  echo "Request completed successfully."
else
  echo "Request failed. Please check the output above for details."
fi
